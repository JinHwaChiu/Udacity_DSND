You'll find the code for the web app in the 3_flask+plotly+pandas folder. Please look through the code to become familiar with it. 

Remember to see the dashboard, you'll need to start the web app by opening a terminal and typing `cd 3_flask+plotly+pandas` then typing `python worldbank.py` in the terminal. 

Click 'PREVIEW' button to open the homepage
