# Instructions

Practice using jQuery to add animation.

Go to the 4_exercise_jquery folder's textchange.js file and follow the TODO instructions. Notice that in the index.html, the jquery library and textchange.js file have already been linked for you in the <head> tag:
  
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="textchange.js"></script>
  
When you're finished, there is a solution file in the solution folder.