# Instructions

Practice using Boostrap to style a web page.

Go to the 5_exercise_boostrap folder. Open the index.html file.  The index.html contains a generic starter template from the Bootstrap website that you can find here:
https://getbootstrap.com/docs/4.1/getting-started/introduction/

We've added TODOs to this file for you to fill out. 

Notice that there is a folder called 'assets', which contains the images you'll use to complete the exercise.

  
When you're finished, there is a solution html file in the solution folder. The solution folder also contains an image of what the final result should look like.