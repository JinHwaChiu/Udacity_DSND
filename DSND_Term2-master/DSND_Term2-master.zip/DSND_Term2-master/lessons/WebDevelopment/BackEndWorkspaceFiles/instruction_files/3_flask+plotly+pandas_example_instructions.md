You'll find the code for the web app in the 3_flask+plotly+pandas folder. Please look through the code to become familiar with it. 

Remember to see the dashboard, you'll need to start the web app by opening a terminal and typing `cd 3_flask+plotly+pandas` then typing `python worldbank.py` in the terminal. 

Then you need to find the workspace environmental variables with `env | grep WORK`, and you can open a new browser window and go to the address:
`http://WORKSPACESPACEID-3001.WORKSPACEDOMAIN` replacing WORKSPACEID and WORKSPACEDOMAIN with your values.
